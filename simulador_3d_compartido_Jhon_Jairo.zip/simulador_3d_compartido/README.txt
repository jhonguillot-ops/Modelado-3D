SIMULADOR 3D COMPARTIDO — JHON JAIRO GUILLOT GRANADOS

Incluye:
- Modelo 3D interactivo con Three.js.
- Dimensiones reales iniciales: 8 m × 20 m × 2,85 m.
- Área, perímetro, volumen y costo estimado calculados automáticamente.
- Acceso mediante clave.
- Comentarios compartidos entre los usuarios que entren a la misma página.
- Diseño adaptable a celular y computador.

CLAVE INICIAL:
Arquitectura2026

CAMBIAR LA CLAVE:
Antes de ejecutar, define la variable ACCESS_PASSWORD.
Ejemplo:
ACCESS_PASSWORD="TuClaveSegura" npm start

EJECUTAR EN UN COMPUTADOR:
1. Instala Node.js 18 o superior.
2. Abre una terminal en esta carpeta.
3. Ejecuta: npm start
4. Abre: http://localhost:3000

PARA QUE ENTRE EL GRUPO Y EL PROFESOR DESDE INTERNET:
Este proyecto necesita publicarse en un servicio que ejecute Node.js (por ejemplo Render, Railway, Fly.io o un servidor propio). GitHub Pages por sí solo no puede ejecutar el servidor de comentarios.

IMPORTANTE:
- El archivo comments.json guarda los comentarios.
- En servicios sin almacenamiento persistente, configura un disco/volumen persistente o cambia el almacenamiento a una base de datos.
- La clave del ejemplo debe cambiarse antes de publicar.
- Las imágenes futuras del proyecto pueden incorporarse como sección adicional, pero el modelo 3D en vivo es la parte interactiva.
