import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, 'public');
const commentsFile = path.join(__dirname, 'comments.json');
const PORT = process.env.PORT || 3000;
const PASSWORD = process.env.ACCESS_PASSWORD || 'Arquitectura2026';
const sessions = new Set();

function readComments(){ try{return JSON.parse(fs.readFileSync(commentsFile,'utf8'));}catch{return [];} }
function writeComments(x){ fs.writeFileSync(commentsFile, JSON.stringify(x,null,2)); }
function send(res,status,data,type='application/json'){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store'});res.end(type==='application/json'?JSON.stringify(data):data);}
function parseCookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').filter(Boolean).map(v=>{const i=v.indexOf('=');return [v.slice(0,i).trim(),decodeURIComponent(v.slice(i+1).trim())]}));}
function auth(req){const s=parseCookies(req).sid;return s&&sessions.has(s);}
function serveFile(res,file){const ext=path.extname(file);const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};fs.readFile(file,(e,d)=>e?send(res,404,'No encontrado','text/plain'):send(res,200,d,types[ext]||'application/octet-stream'));}

const server=http.createServer(async (req,res)=>{
  const u=new URL(req.url,`http://${req.headers.host}`);
  if(u.pathname==='/api/login' && req.method==='POST'){
    let body=''; req.on('data',c=>body+=c); req.on('end',()=>{try{const p=JSON.parse(body); if(p.password!==PASSWORD)return send(res,401,{ok:false,error:'Clave incorrecta'}); const sid=crypto.randomUUID(); sessions.add(sid); res.writeHead(200,{'Content-Type':'application/json','Set-Cookie':`sid=${encodeURIComponent(sid)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400`,'Cache-Control':'no-store'}); res.end(JSON.stringify({ok:true}));}catch{send(res,400,{ok:false,error:'Solicitud inválida'});}}); return;
  }
  if(u.pathname==='/api/session'){return send(res,200,{ok:auth(req)});}
  if(u.pathname==='/api/comments' && req.method==='GET'){if(!auth(req))return send(res,401,{error:'No autorizado'});return send(res,200,{comments:readComments()});}
  if(u.pathname==='/api/comments' && req.method==='POST'){
    if(!auth(req))return send(res,401,{error:'No autorizado'}); let body=''; req.on('data',c=>body+=c); req.on('end',()=>{try{const p=JSON.parse(body);const name=String(p.name||'Anónimo').trim().slice(0,60);const text=String(p.text||'').trim().slice(0,500);if(!text)return send(res,400,{error:'Comentario vacío'});const comments=readComments();comments.push({id:crypto.randomUUID(),name,text,date:new Date().toLocaleString('es-CO')});writeComments(comments);send(res,200,{ok:true});}catch{send(res,400,{error:'Solicitud inválida'});}});return;
  }
  if(u.pathname==='/api/logout'){const sid=parseCookies(req).sid;if(sid)sessions.delete(sid);res.writeHead(200,{'Set-Cookie':'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0','Content-Type':'application/json'});return res.end(JSON.stringify({ok:true}));}
  const file=u.pathname==='/'?path.join(publicDir,'index.html'):path.join(publicDir,u.pathname.replace(/^\//,''));
  if(!file.startsWith(publicDir))return send(res,403,'Prohibido','text/plain');
  if(!auth(req) && u.pathname!=='/login.js') return serveFile(res,path.join(publicDir,'index.html'));
  serveFile(res,file);
});
server.listen(PORT,()=>console.log(`Simulador en http://localhost:${PORT}`));
